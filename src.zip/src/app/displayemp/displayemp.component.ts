import { Component, OnInit } from '@angular/core';
import {  ViewChild, ElementRef, Renderer2, AfterViewInit ,TemplateRef} from '@angular/core';
import {ProjectdataService} from '../projectdata.service';
import { NgbActiveModal, NgbModal,NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';

@Component({
  selector: 'app-displayemp',
  templateUrl: './displayemp.component.html',
  styleUrls: ['./displayemp.component.scss']
})
export class DisplayempComponent implements OnInit,AfterViewInit {
	 static activeModal: any;
  storeValue:any;
  sample;
    myDateValue: Date;
    modalReference: NgbModalRef;
      @ViewChild("content") modalContent: TemplateRef<any>;
  constructor(public dataservice: ProjectdataService,public activeModal: NgbActiveModal,public NgbModal:NgbModal) { }

  ngOnInit(): void {
     this.myDateValue = new Date();
  }
 ngAfterViewInit(){
  
      this.dataservice.getData().subscribe(msg1=>{
      console.log(msg1);
      console.log(msg1["Data"]);
    
      this.sample=msg1["Data"];


    });
    }

  public getDismissReason(reason: any): string {
   
    return "getdismissedreason";
  }

 async editValue (event,value)  {

    var idVal =event.target.getAttribute("id")
    idVal=idVal.replace(/^edit+/i, '');
    console.log(idVal);
   console.log(this.sample[value-1]);


//document.getElementById("updateCost").setAttribute("placeholder",this.sample[idVal-1]["Cost"]);
console.log(this.sample[value-1]["joining"]);
  this.modalReference=  this.NgbModal.open(this.modalContent);
(document.getElementById("updateEmployee") as HTMLInputElement).value =this.sample[value-1]["Employee name"];
(document.getElementById("updateDesig") as HTMLInputElement).value=this.sample[value-1]["designation"];
(document.getElementById("updateContact") as HTMLInputElement).value=this.sample[value-1]["contact"];


  this.modalReference.result.then((result) => {
       console.log("yes opened");
       console.log(result);
        let msg = this.dataservice.editData(idVal,result["updateEmployee"],result["updateDesig"],result["updateContact"]);
      console.log(msg);

    this.ngAfterViewInit();      });
   
     
  }

  deleteValue(event){
    console.log(event);
   var idVal =event.target.getAttribute("id")
    idVal=idVal.replace(/^delete+/i, '');
    console.log(idVal);
       let msg = this.dataservice.deleteData(idVal).then((result)=>{
         this.ngAfterViewInit();  
       });
  
          
  }

  ok(){
    console.log("yes");
    console.log((document.getElementById("updateEmployee") as HTMLInputElement).value);
     var updateEmployee=(document.getElementById("updateEmployee") as HTMLInputElement).value;
      var updateDesig=(document.getElementById("updateDesig") as HTMLInputElement).value;
            var updateContact=(document.getElementById("updateContact") as HTMLInputElement).value;


       this.modalReference.close({"updateEmployee":updateEmployee,"updateDesig":updateDesig,"updateContact":updateContact});
  }




}
