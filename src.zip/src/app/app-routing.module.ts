import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DisplayempComponent} from './displayemp/displayemp.component';
import {GetempComponent} from './getemp/getemp.component'; 
import {SigninComponent} from './signin/signin.component';


const routes: Routes = [{path:"",component:SigninComponent
},
{path:"displaycomp",component:DisplayempComponent},
{path:"addEmployee",component:GetempComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
