import { Injectable } from '@angular/core';
import { Observable,BehaviorSubject,Subject } from 'rxjs';
import { Http, HttpModule,RequestOptionsArgs, RequestOptions,Headers} from '@angular/http';


@Injectable({
  providedIn: 'root'
})
export class ProjectdataService {

 APIUrl;
    baseUrl;

     //private subject = new Subject<any>();

  constructor(private http:Http) { 
    /*console.log(appConfig)
  	 this.APIUrl=appConfig.config.apiURL;
      this.baseUrl=appConfig.config.baseURL;*/

      var hostname=window.location.hostname;
        this.APIUrl = "http://"+hostname+":3500";
        this.baseUrl = "http://"+hostname;}



        getData(){
  var getDetailsUrl = this.APIUrl + "/retrievedata";   
     var subject = new Subject<string>();
     this.http.post(getDetailsUrl,{}).subscribe((result)=>{
        console.log('promise on',result)
   subject.next(  result.json());   });


    
   return subject.asObservable();
     

}


storeData(Elem1,Elem2,Elem3,Elem4){
    var getDetailsUrl = this.APIUrl + "/getdata";   
      var data={Elem1:Elem1,Elem2:Elem2,Elem3:Elem3};
	 //var subject = new Subject<string>();
   return new Promise(async (resolve,reject)=>{
        await this.http.post(getDetailsUrl,{Elem1:Elem1,Elem2:Elem2,Elem3:Elem3,Elem4:Elem4}).subscribe((result)=>{
        console.log('promise on',result)
         resolve(result)
        })
      })
   console.log("jfj")
}

editData(idVal,updateEmployee,updateDesig,updateContact){
  console.log(idVal);
 var EditUrl = this.APIUrl + "/editdata";   

   //var subject = new Subject<string>();
   return new Promise(async (resolve,reject)=>{
        await this.http.post(EditUrl,{id:idVal,updateEmployee:updateEmployee,updateDesig:updateDesig,updateContact:updateContact}).subscribe((result)=>{
        console.log('promise on',result)
         resolve(result)
        })
      })
   console.log("jfj1")
}


deleteData(idVal){
   var DeleteUrl = this.APIUrl + "/deletedata";  
   return new Promise(async (resolve,reject)=>{
        await this.http.post(DeleteUrl,{id:idVal}).subscribe((result)=>{
        console.log('promise on',result)
         resolve(result)
        })
      })
      console.log("jfj2")
}


getsignin(){
  var signinurl = this.APIUrl +"/getsignin";
   var subject = new Subject<string>();
     this.http.post(signinurl,{}).subscribe((result)=>{
        console.log('promise on',result)
   subject.next(  result.json());   });

     
   return subject.asObservable();

}

}