import { Component, OnInit } from '@angular/core';
import {ProjectdataService} from '../projectdata.service';
import {  ViewChild, ElementRef, Renderer2, AfterViewInit ,TemplateRef} from '@angular/core';
import {Router,ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {

  constructor(public dataservice: ProjectdataService,public router: Router,private route: ActivatedRoute) { 

    this.route.params.subscribe(params => {
      console.log(params);
      
    });
    	

}
  sample;
 
  ngOnInit(): void {
  }
    onSubmit(){
    	let navigatein = () => {
    		this.router.navigate(['displaycomp']);
    	}


    	this.sample.map(function(value,index){

    		if((value["username"] == (document.getElementById("username") as HTMLInputElement).value )&& (value["password"] == 	(document.getElementById("password") as HTMLInputElement).value)){
    			navigatein();
    		

    		}
    	})
    	


    }
ngAfterViewInit(){
  
      this.dataservice.getsignin().subscribe(msg1=>{
    
      this.sample=msg1["Data"];


    });
    }

  
}
