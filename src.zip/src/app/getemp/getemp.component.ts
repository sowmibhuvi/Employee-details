import { Component, OnInit } from '@angular/core';
import {  ViewChild, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
import {ProjectdataService} from '../projectdata.service';
import { Observable, Subject } from 'rxjs';
import { Subscription } from 'rxjs';

import {Router} from '@angular/router';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
@Component({
  selector: 'app-getemp',
  templateUrl: './getemp.component.html',
  styleUrls: ['./getemp.component.scss']
})
export class GetempComponent implements OnInit {

	 @ViewChild('employeeName') employeeName: ElementRef;
	  @ViewChild('designation') designation: ElementRef;
	   @ViewChild('contact') contact: ElementRef;
@ViewChild('dp') d:ElementRef;

  myDateValue: Date;
subscription: Subscription;
  title = 'Employee-Detail';
  constructor(public dataservice: ProjectdataService, public router: Router) { }

  ngOnInit(): void {
  	    this.myDateValue = new Date();
  	    console.log(this.myDateValue);
  }
 getValue(){



  		var employeeName= this.employeeName.nativeElement.value
  		var designation=this.designation.nativeElement.value

  		var contact=this.contact.nativeElement.value

  		var date = this.d.nativeElement.value

      if(employeeName !="" && designation !=""  && contact!="" && date!=""){



      let msg = this.dataservice.storeData(employeeName,designation,contact,date);
      console.log(msg);
      

           document.getElementById("dangermsg").style.display="none";
   
         document.getElementById("successmsg").style.display="block";
 setTimeout(() => {
             this.router.navigate(["displaycomp"]);
 }
 , 3000);

      }else{
          document.getElementById("dangermsg").style.display="block";
   
         document.getElementById("successmsg").style.display="none";
      }






  }

 
}
