import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DisplayempComponent } from './displayemp/displayemp.component';
import { GetempComponent } from './getemp/getemp.component';
import { SigninComponent } from './signin/signin.component';
import {NgbModule,NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {HttpClientModule} from '@angular/common/http';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReplacePipe } from './replace.pipe';
@NgModule({
  declarations: [
    AppComponent,
    DisplayempComponent,
    GetempComponent,
    SigninComponent,
    ReplacePipe
  ],
  imports: [
    BrowserModule,
         HttpClientModule,
    AppRoutingModule,
            HttpModule,
        NgbModule,
         BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot() 
  ],
  providers: [
      NgbActiveModal],
  bootstrap: [AppComponent]
})
export class AppModule { }
